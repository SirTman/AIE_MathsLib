#pragma once

int add(int a, int b);